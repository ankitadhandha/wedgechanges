
print '''

<html>
<body>

<form>

<input type=text name=a>

<p>

<input name=button type=submit value=Hello>

</form>

<p>
fields = %s

</html>
''' % fields

