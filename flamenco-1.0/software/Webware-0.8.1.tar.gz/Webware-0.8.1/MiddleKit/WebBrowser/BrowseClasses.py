from StorePage import StorePage


class BrowseClasses(StorePage):

	def writeContent(self):
		self.writeln('Click a class on the left to browse all objects of that class.')
