def test(store):
	from Thing import Thing
	# nothing more to do here
