from Attr import Attr


class AnyDateTimeAttr(Attr):
	def __init__(self, dict):
		Attr.__init__(self, dict)
