from BasicTypeAttr import BasicTypeAttr


class DecimalAttr(BasicTypeAttr):
	# @@ 2003-01-14 ce: it would make more sense if the Float type spewed a SQL decimal type in response to having "precision" and "scale" attributes.
	pass
