from BasicTypeAttr import BasicTypeAttr


class IntAttr(BasicTypeAttr):
	pass
