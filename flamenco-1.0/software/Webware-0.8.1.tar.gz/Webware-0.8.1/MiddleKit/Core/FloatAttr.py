from BasicTypeAttr import BasicTypeAttr


class FloatAttr(BasicTypeAttr):
	pass
